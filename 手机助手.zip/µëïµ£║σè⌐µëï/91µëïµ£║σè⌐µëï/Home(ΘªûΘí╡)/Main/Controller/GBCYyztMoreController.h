//
//  GBCYyztMoreController.h
//  91手机助手
//
//  Created by Denny_cheng on 15/9/30.
//  Copyright (c) 2015年 Denny_cheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GBCYyztMoreController : UIViewController
@property(nonatomic,strong) NSArray *arrYyzt;

@end
