//
//  NSString+WYString.h
//  0729-－qq
//
//  Created by admin on 15/7/30.
//  Copyright (c) 2015年 wyzc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (WYString)
-(CGSize)calcSizeWithFont:(UIFont *)font maxWith:(CGFloat)maxWith;








@end
